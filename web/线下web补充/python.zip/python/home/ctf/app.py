#!/usr/bin/env python3
# -*- coding:utf-8 -*-
import tornado.ioloop
import tornado.web
import random
import os
import yaml


class Index(tornado.web.RequestHandler):
    def get(self):
        black_list = ['{{', '(', ')']
        username = self.get_argument('username', 'guest')
        if username == 'guest':
            return self.write('<h1>Hello {}</h1>'.format(username))
        for _black in black_list:
            if _black in username:
                return self.render_string("error.html")
        filename = "{}.html".format(random.randint(1000000, 10000000))
        with open(filename, 'w') as f:
            f.write("""<html>
                <head>
                <style>body{font-size: 30px;}</style>
                </head>
                <body>%s</body>
                </html>\n""" % username)
        self.render(filename)
        os.system('rm {}'.format(filename))


class FileRead(tornado.web.RequestHandler):
    def get(self):
        filename = self.get_argument('filename')
        if filename:
            with open(filename, 'r+') as f:
                file_text = f.read()
                return self.write(file_text)
        else:
            return self.write('<h1>not filename input</h1>')

class YamlLoad(tornado.web.RequestHandler):
    def post(self):
        yaml_content = self.get_argument('yaml')
        deser_content = yaml.load(yaml_content)
        return self.write(deser_content)


def make_app():
    return tornado.web.Application([
        (r"/", Index),
        (r"/read", FileRead),
        (r"/yaml",YamlLoad)
    ])


if __name__ == "__main__":
    port = 8000
    app = make_app()
    app.listen(port, '0.0.0.0')
    print('[+]The server start at http://0.0.0.0:{}'.format(str(port)))
    tornado.ioloop.IOLoop.current().start()
