#!/bin/bash
echo ctf:default | chpasswd;
echo root:root | chpasswd;

nohup python3 /home/ctf/app.py &
tail -f /dev/null
