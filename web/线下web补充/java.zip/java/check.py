import requests


class check:
    url = ""
    is_down = False
    logs = " "

    def __init__(self, url):
        self.url = url
        self.logs += url

    def check_index(self):
        try:
            res = requests.get(self.url, timeout=5, verify=False)
            if res.status_code != 200:
                self.is_down = True
                self.logs += " check_index down|"
        except Exception as e:
            self.is_down = True
            self.logs += " check_index down %s|" % e


    def check_getuser(self):
        target = self.url + "/user/aa?username=a"
        try:
            res = requests.get(target, timeout=5, verify=False)
            if res.status_code != 200:
                self.is_down = True
                self.logs += " check_getuser down|"
        except Exception as e:
            self.is_down = True
            self.logs += " check_getuser down %s|" % e

    def check_remember(self):
        target = self.url + "/;/remember"
        headers = {"Cache-Control": "max-age=0", "Upgrade-Insecure-Requests": "1",
                   "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:84.1) Gecko/20100101 Firefox/84.1",
                   "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                   "Accept-Encoding": "gzip, deflate", "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
                   "Connection": "close", "Content-Type": "application/x-www-form-urlencoded"}
        data = {
            "persondata": "rO0ABXNyABFheC5hd2RnYW1lLlBlcnNvblqjUj3i0QKBAgACSQAFbGVudGhMAARuYW1ldAASTGphdmEvbGFuZy9TdHJpbmc7eHAAAeG5dAAHYWFhYmJjYw=="}
        try:
            res = requests.post(target, data=data, timeout=5, verify=False, headers=headers, proxies={"http":"127.0.0.1:8081"})
            if "aaabbcc" not in res.text:
                self.is_down = True
                self.logs += " check_remember down|"
        except Exception as e:
            self.is_down = True
            self.logs += " check_remember down %s|" % e

    def write_log(self, log):
        with open("log.txt", "a+") as f:
            f.writelines(log)
        print(log)

    def start_check(self):
        self.check_index()
        self.check_getuser()
        self.check_remember()
        if self.is_down:
            self.write_log("down: " + self.logs)
            return True
        else:
            self.write_log("alive: " + self.logs)
            return False


if __name__ == "__main__":
    url = "http://129.226.116.254:8000/"
    if check(url).start_check():
        print("[-] %s down" % url)
        # 执行扣分操作
    else:
        print("[+] %s alive" % url)
