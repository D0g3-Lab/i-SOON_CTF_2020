#!/bin/bash
mysqladmin -u root password "mysql57mysql" &&\
mysql -u root -pmysql57mysql -e "create database phpok5 CHARACTER SET utf8 COLLATE utf8_general_ci;" &&\
mysql -u root -pmysql57mysql phpok5 < /var/www/html/db.sql --default-character-set=utf8  &&\
mysql -u root -pmysql57mysql -e "CREATE USER 'phpok'@'localhost' IDENTIFIED BY '98vwqld912!@823c@#';"&&\
mysql -u root -pmysql57mysql -e "revoke all privileges on *.* from phpok@localhost;"&&\
mysql -u root -pmysql57mysql -e "grant SELECT, INSERT, UPDATE, DELETE on *.* to phpok@'localhost' identified by '98vwqld912!@823c@#';"