#!/bin/bash
ulimit -t 1
# ulimit -u 5
service apache2 start;