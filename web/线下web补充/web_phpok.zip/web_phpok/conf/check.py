# -*- coding:utf8 -*-
import requests as rq
import sys, json
my_time = "AAAA"
debug = True
host = 'localhost'
port = 80
headers = {"User-Agent":"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36"}

class check():
    def __init__(self):
        a = 1

    def index_check(self):
        res = rq.get('http://%s:%s/index.php'% (host,port),headers=headers)
        if 'Shenzhen Kunwu Technology Co., Ltd.' in res.text:
            return True
        if debug:
            print("[fail!] index_check_fail")
        return False
    

    def search_check(self):
        res = rq.post('http://%s:%s/index.php?c=search'% (host,port),data = {'keywords':'apple'},headers=headers)
        data = json.loads(json.dumps(dict(res.headers)))['Content-Length']
        if data == '2804':
            return True
        if debug:
            print("[fail!] search_check_fail")
        return False


    def admin_check(self):
        data = {'user':'admin','pass':'admin123'}
        res = rq.post('http://%s:%s//admin.php?c=login&f=ok'% (host,port),data=data,headers=headers)
        if "管理员" in res.text:
            return True
        if debug:
            print("[fail!] admin_check_fail")
        return False
    

    def login_check(self):
        res = rq.get('http://%s:%s/http://50.3.232.201:60180/index.php?c=login'% (host,port),headers=headers)
        if 'Forgot password' in res.text:
            return True
        if debug:
            print("[fail!] login_fail")
        return False


def server_check():
    try:
        a = check()
        if not a.index_check():
            return False
        if not a.search_check():
            return False
        if not a.admin_check():
            return False    
        return True
    except Exception as e:
        print(e)
        return False

if __name__ == '__main__':
    host = sys.argv[1]
    port = sys.argv[2]

    if server_check():
        # print("Host: "+host+" seems ok")
        pass
        # scores.append("1")
    else:
        # 10180 11080
        print("team"+port[1:3])
        # print("Host: "+host+" seems down")
        # scores.append("-1")
    # game_round += 1


