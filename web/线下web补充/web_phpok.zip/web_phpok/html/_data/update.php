<?php
if(!defined("PHPOK_SET")){exit("<h1>Access Denied</h1>");}
$uconfig["status"] = "1";
$uconfig["server"] = "http://update.phpok.com/5/";
$uconfig["date"] = "10";
$uconfig["ip"] = "";
$uconfig["onlyid"] = "06af7c21f6d41d613ee8fabfbe5d9092";

//-----end