<?php exit();?>
---start---Time:20:11:15---------------------
APP_ID: www
CTRL_ID: index
FUNC_ID: index
INFO:
SQL错误，: 数据库连接失败，错误信息：SQLSTATE[HY000] [2002] Connection refused
---end---
---start---Time:20:11:16---------------------
APP_ID: www
CTRL_ID: index
FUNC_ID: index
INFO:
SQL错误，: 数据库连接失败，错误信息：SQLSTATE[HY000] [2002] Connection refused
---end---
---start---Time:20:11:27---------------------
APP_ID: admin
CTRL_ID: index
FUNC_ID: index
INFO:
SQL错误，: 数据库连接失败，错误信息：SQLSTATE[HY000] [2002] Connection refused
---end---
---start---Time:20:11:27---------------------
APP_ID: admin
CTRL_ID: index
FUNC_ID: index
INFO:
SQL错误，: 数据库连接失败，错误信息：SQLSTATE[HY000] [2002] Connection refused
---end---
