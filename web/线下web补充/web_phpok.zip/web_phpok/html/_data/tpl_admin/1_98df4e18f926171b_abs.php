<?php if(!defined("PHPOK_SET")){exit("<h1>Access Denied</h1>");} ?><?php $this->assign("nopadding","true"); ?><?php $this->output("head_lay","file",true,false); ?>
//
<?php $this->assign("is_open","true"); ?><?php $this->output("foot_lay","file",true,false); ?>