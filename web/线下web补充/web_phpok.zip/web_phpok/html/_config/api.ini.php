;<?php exit("<h1>Access Denied</h1>");?>

;is_vcode = true

; API 接口生成的图片如果异常，可在这里关闭 gzip 模式
gzip = false
