#include <iostream>
#include <cstdlib>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <alloca.h>
#include <string.h>

using namespace std;

#define NUM_THREADS	5

struct thread_data{
	pthread_t *a;
};
void hello(){
	system("cat flag");
}

void *thread_cannel(void *threadarg){
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED,NULL);
	// my_data = (struct thread_data *) threadarg;
	short beat_num = 0;
	cin >> beat_num;
	if(beat_num > 20 || beat_num < 1){
		cout << "马老师: 正蹬鞭腿左刺拳训练有素,看来是有备而来!" << endl;
		pthread_exit(NULL);
	}

	char *allocsp = (char *)alloca(beat_num);
	cin >> allocsp;
	if(allocsp != NULL){
		cout << "马老师全部防区防出去了啊,防出去以后自然是传统功夫以点到为止,右拳放在了你鼻子上,没打你." << endl;
	}

	while(true){
		pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,NULL);
		sleep(1);
		pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
		pthread_testcancel();
	}
	pthread_exit(NULL);
}

void *thread_no_cannel(void *threadarg){
	short beat_num = 0;
	cin >> beat_num;
	if(beat_num > 20 || beat_num < 1){
		cout << "马老师: 正蹬鞭腿左刺拳训练有素,看来是有备而来!" << endl;
		pthread_exit(NULL);
	}

	char *allocsp = (char *)alloca(beat_num);
	cin >> allocsp;
	if(allocsp != NULL){
		cout << "马老师全部防区防出去了啊,防出去以后自然是传统功夫以点到为止,右拳放在了你鼻子上,没打你." << endl;
		if(beat_num == 5 && !strcmp(allocsp, "sneak")){
			cout << "你突然袭击左刺拳来打他脸,他大E了啊,没有闪." << endl;
		}
	}
	return 0;
}

void end_ma(){

	cout << endl << "这两个年轻人,不讲武德." << endl;
	cout << "来,骗!" << endl;
	cout << "来,偷袭!" << endl;
	cout << "我,69岁的老同志.这好吗?这不好." << endl;
	cout << "我劝,年轻人,耗子尾汁." << endl;
	cout << "武林,要以和为贵,要讲武德,不要搞窝里斗." << endl;
	cout << "谢谢朋友们!" << endl;
}

void begin_ma(){
	cout << "本次赛题,出于11-28之前,题目内容纯属玩梗,但没想到人民日报点名批评了该事件,由于再无其他时间重新出题,所以请谅解!!!" << endl;
	cout << "马老师: 朋友们好啊,我是混元形意太极门掌门人马xx" << endl;
	cout << "年轻人: 马老师,你能不能教教我混元功法?" << endl;
	cout << "马老师: 你在健身房练死劲,不好用.传统功夫是讲化劲的,四两拨千斤,200多斤的英国大力士都挝不动我这一个手指头." << endl;
	cout << "年轻人: 马老师,那我请个英国大力士和你试试?" << endl;
	cout << "马老师: 可以." << endl;
	cout << "说完,你,啪的一下,就站起来了,很快啊!" << endl << endl;
}

int main(void){
	// alarm(8);
	// cout << "pid = " << getpid() << endl;
	pthread_t threads[NUM_THREADS];
	struct thread_data td[NUM_THREADS];
	int rc;
	int i;
	size_t stacksize;
	pthread_attr_t attr;
	int ret;
	ret = pthread_attr_init(&attr);
	if(ret != 0){
		//cout << "pthread_attr_init error." << endl;
		return -1;
	}
	stacksize = 1024 * 20;
	ret = pthread_attr_setstacksize(&attr, stacksize);
	if(ret != 0){
		// cout << "pthread_attr_setstacksize error." << endl;
		cout << ret << endl;
		return -1;
	}
	
	begin_ma();

	cout << "下面请输入你想要挑战马老师几次: ";
	int open_num = 0;
	cin >> open_num;
	if(open_num > 2){
		cout << "马老师: 年轻人,不讲武德,我闪电鞭才五式!" << endl;
		end_ma();
		return 0;
	}

	cout << "下面请依次输入你想要招式能量值(招式长度)以及你想要打的招式" << endl;
	cout << "例如,挑战马老师2次:" << endl;
	cout << "3" << endl;
	cout << "左刺拳" << endl;
	cout << "3" << endl;
	cout << "右鞭腿" << endl;

	for( i=0; i<open_num; i++ ){

		if (i == open_num-1){
			rc = pthread_create(&threads[i], &attr, thread_no_cannel, NULL);
			if (rc){
				// cout << "pthread_create error," << rc << endl;
				exit(-1);
			}
		}else{
			rc = pthread_create(&threads[i], &attr, thread_cannel, NULL);
			if (rc){
				// cout << "pthread_create error," << rc << endl;
				exit(-1);
			}
		}
		sleep(0.1);
	}

	i = i - 1;
	rc = pthread_join(threads[i], NULL);
	if (rc != 0){
		// cout << "pthread_exit error" << rc << endl;
		exit(-1);
	}
	// cout << "我来了" << rc << endl;
	for( i=0; i<open_num-1; i++ ){
		pthread_cancel(threads[i]);
		rc = pthread_join(threads[i], NULL);
		if (rc != 0){
			// cout << "pthread_exit error" << rc << endl;
			exit(-1);
		}
	}
	
	end_ma();
	pthread_exit(NULL);
	return 0;
}