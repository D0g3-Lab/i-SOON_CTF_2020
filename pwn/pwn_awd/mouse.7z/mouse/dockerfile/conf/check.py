from pwn import *
from sys import *
import time

host = argv[1]
port = int(argv[2])
timeout = 30

context.log_level = 'critical'

def sendone(p):
	try:
		p.recvuntil(': ', timeout = 1)
		p.sendline('1')
		p.recvuntil('3\n', timeout = 1)
		p.recvuntil('3\n', timeout = 1)
		p.recvuntil('\n', timeout = 1)
		p.sendline("2")
		p.sendline('aa')
		p.recvuntil('!\n', timeout = 1)
		p.recvuntil('!\n', timeout = 1)
		return p.recvuntil('!\n', timeout = 1)
	except Exception as e:
		raise Exception, "sendone error, "+str(e)

def sendtwo(p):
	try:
		p.recvuntil(': ', timeout = 1)
		p.sendline('2')
		p.recvuntil('3\n', timeout = 1)
		p.recvuntil('3\n', timeout = 1)
		p.recvuntil('\n', timeout = 1)
		p.sendline("2")
		p.sendline('aa')
		p.sendline("2")
		p.sendline('aa')
		p.recvuntil('!\n', timeout = 1)
		p.recvuntil('!\n', timeout = 1)
		return p.recvuntil('!\n', timeout = 1)
	except Exception as e:
		raise Exception, "sendtwo error, "+str(e)

def getIO():
    return remote(host, port, timeout=timeout)

# normal I/O check && check malicious modification of <free>
def check1():
	try:
		p = getIO()

		info = sendone(p)
		if info == None:
			raise Exception, "returnsendone not same"
		
		p.close()
	except Exception as e:
		p.close()
		raise Exception, "check1 error, "+str(e)
	return True

# check the range of allocation size 
def check2():
	try:
		p = getIO()
		info = sendtwo(p)
		if info == None:
			raise Exception, "returnsendtwo not same"
		p.close()
	except Exception as e:
		p.close()
		raise Exception, "check2 error, "+str(e)
	return True
	
# check the all-defend script
def check3():
	try:
		p = getIO()

		info = add(p, 0x100, p64(0x7f0d86557ba0))
		if info != "done[010]\n":
			raise Exception, "may use an all-defend script"
		info = add(p, 0x100, p64(0x556ac6b4d010))
		if info != "done[120]\n":
			raise Exception, "may use an all-defend script"
		info = add(p, 0x100, 'cat flag')
		if info != "done[230]\n":
			raise Exception, "may use an all-defend script"
		info = add(p, 0x100, '/bin/sh')
		if info != "done[340]\n":
			raise Exception, "may use an all-defend script"
		info = quit(p)
		if info != "0: \xa0\x7b\x55\x86\x0d\x7f\n1: \x10\xd0\xb4\xc6\x6a\x55\n2: cat flag\n3: /bin/sh\ngood bye!\n":
			raise Exception, "may use an all-defend script"
		p.close()
	except Exception as e:
		p.close()
		raise Exception, "check3 error, "+str(e)
	return True

def checker():
	try:
		if check1() and check2(): # and check3():
#			return (True, "team: " + str(port) + " OK")
			pass
	except Exception as e:
#		return (False, "team: " + str(port) + " is down, "+str(e))
		print "team" + str(port)[1:3]

if __name__ == '__main__':
    checker()

