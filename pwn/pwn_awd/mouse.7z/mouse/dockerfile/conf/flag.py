#!/usr/bin/python
# -*- coding: UTF-8 -*- 
import hashlib
import MySQLdb
import time
import random, sys

def genFlag(key):
	# 
	randomKey = str(random.random())
	key += randomKey
	md5 = hashlib.md5()
	md5.update(key.encode(encoding='utf-8'))
	flag = md5.hexdigest()
	flag = 'flag{' + flag + '}'
	return flag

# Flag放到Linux根目录
def main(key, teamId, interval):
	# 正则替换下面两个字段
	while 1:
		flag = genFlag(key)
		# 根据权限情况调整
		filePath = "/home/pwn/flag"
		writeToFile(filePath, flag)
		writeToDb(flag, teamId)
		print("Update Finished. " + teamId + " " + flag)
		time.sleep(int(interval))


# 将flag覆盖写入指定文件
def writeToFile(filename, flag):
	file = open(filename,"w")
	file.write(str(flag))
	file.close()

# 权限，数据库。
# 将flag插入mysql数据库，同时插入队伍信息和时间【根据ID和数据库结构改一下。高铁上尽量把环境生成部分写完，下午阿康就可以开始调试了】
def writeToDb(flag, teamid):
	db = MySQLdb.connect(
	# 这里也是要正则替换的，估计
	host = "i0gan.cn",
	user = "root",
	port = 65533,
	passwd = "123456",
	db = "awd"
	)
	sql = "update instances set flag='%s',lastbroke=NOW() where name='%s'" % (flag,teamid)
	cur = db.cursor()
	
	try:
   		# 执行SQL语句
   		cur.execute(sql)
   		# 提交到数据库执行
   		db.commit()
	except Exception as e:
   		# 发生错误时回滚
   		db.rollback()

   	db.close()

if __name__=='__main__':
	main(sys.argv[1],sys.argv[2],sys.argv[3])
