#!/bin/sh
# server script

/etc/init.d/xinetd start;
sleep infinity;
