/*@
 * author: i0gan
 * src for: axb 2020 pwn 1 [web server]
 */

#include "http.hh"
#include <seccomp.h>
#include <linux/seccomp.h>
void do_seccomp()
{
/*
int_malloc
sysmalloc
sbrk
brk
*/
    scmp_filter_ctx ctx;
    ctx = seccomp_init(SCMP_ACT_KILL);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(openat), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(close), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(fstat), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(mmap), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(munmap), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(brk), 0);
    if(seccomp_load(ctx) < 0){
        //std::cout << "seccomp_error.\n";
        exit(0);
    }
}

void init() {
    setbuf(stdin, nullptr);
    setbuf(stdout, nullptr);
    do_seccomp();
}

int main() {
    init();
    lgx::net::http http(0, 1);
    for(int i = 0; i < 1000; ++i) {
        http.handle_read();
    }
    return 0;
}
