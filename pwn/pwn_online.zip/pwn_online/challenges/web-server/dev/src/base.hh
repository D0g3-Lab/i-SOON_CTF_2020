/*@
 * author: i0gan
 */

#pragma once

#include <memory>
#include <functional>
#include <iostream>
#include <list>
#include <unordered_map>
#include <queue>
#include <sys/time.h>
#include <time.h>

#define d_cout std::cout << "[" << __FILE__ << " line: " << __LINE__ << " thread id: " << std::hex <<  pthread_self() << std::oct << "] "
#define log_dbg(x) "LGX DEBUG:" + std::string(__FILE__) + ":" + std::to_string(__LINE__) + "\n" + std::string(x)
#define LGX_VERSION "1.6"
#define SERVER_NAME "lgx-server " LGX_VERSION
#define MAX_BUF_SIZE 0x500
namespace lgx {
// namespace net start
namespace net {

enum class HttpRecvState;
enum class HttpConnectionState;
enum class HttpParseURIResult;
enum class HttpParseHeaderResult;
enum class HttpResponseCode;

class http_content_type;
class http;
using sp_http = std::shared_ptr<lgx::net::http>;
}
// namespace net end


// namespace work start
namespace work {
class work;
enum class ResponseCode;
}
// namespace work end
namespace util {
using callback = std::function<void()>;
using callback1 = std::function<void(const std::string &)>;
using callback2 = std::function<void(const std::string &, const std::string &)>;
class vessel;
}

namespace crypto {
class url {
public:
    static std::string decode(const std::string &url) {
                std::string ret;
        for(size_t i = 0, j = 0; i < url.size(); ++j, ++i) {
            unsigned char n = 0;
            if(url[i] == '%') {
                if(url[i + 1] >= '0' && url[i + 1] <= '9')      n = (url[i + 1] - '0') * 0x10;
                else if(url[i + 1] >= 'a' && url[i + 1] <= 'f') n = ((url[i + 1] - 'a') + 0x0a) * 0x10;
                else if(url[i + 1] >= 'A' && url[i + 1] <= 'F') n = ((url[i + 1] - 'A') + 0x0a)* 0x10;

                if(url[i + 2] >= '0' && url[i + 2] <= '9')      n += (url[i + 2] - '0');
                else if(url[i + 2] >= 'a' && url[i + 2] <= 'f') n += (url[i + 2] - 'a') + 0x0a;
                else if(url[i + 2] >= 'A' && url[i + 2] <= 'F') n += (url[i + 2] - 'A') + 0x0a;
                i += 2;
            }else n = url[i];
                        ret += n;
        }
        return ret;
    }
};
}
namespace data {
extern std::string root_path;
extern std::string web_page;
extern std::string web_404_page;
extern std::string log_path;
}
}
