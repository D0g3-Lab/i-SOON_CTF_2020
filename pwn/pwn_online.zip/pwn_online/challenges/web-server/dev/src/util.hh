/*@
 * author: i0gan
 */
#pragma once
#include <cstdlib>
#include <string>
#include <string.h>
#include <sys/signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include "base.hh"
#include "vessel.hh"

namespace lgx{
namespace net {
namespace util {
ssize_t read(int fd, std::string &in_buffer, int size);
ssize_t write(int fd, void *buffer, size_t length);
ssize_t write(int fd, lgx::util::vessel &out_buffer);
//int open(const std::string &file);
void ignore_sigpipe();                  //avoid server terminate with SIGPIPE signal
}}}

