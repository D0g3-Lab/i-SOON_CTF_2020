/*@
 * author: i0gan
 */
#pragma once

#include <map>
#include <string>
#include <unistd.h>
#include <sstream>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unordered_map>
#include "base.hh"
#include <cstring>

enum class lgx::work::ResponseCode {
    SUCCESS = 0,
    FAILURE,
    NOT_FOUND,
    INTERNAL_ERROR,
    NO_ACCESS,
    NO_PERMISSSION = 5,
    ERROR_PARSING_URL,
    ERROR_PARSING_CONTENT,
    ERROR_HTTP_CONTENT,
    ERROR_JSON_CONTENT_TYPE,
    ERROR_JSON_CONTENT = 10,
    EXIST,
    NOT_EXIST,
    LOGINED,
};
typedef struct{
    char *ptr;
    int size;
} lgx_data;

class lgx::work::work {
public:
    explicit work(const std::map<std::string, std::string> &map_header_info,
                  const std::map<std::string, std::string> &map_client_info_,
                  std::string &content); // uid for deal with offline
    ~work() {};
    void set_send_data_handler(lgx::util::callback2 send_data_handler);
    void set_error_handler(lgx::util::callback2 error_handler);
    void set_send_file_handler(lgx::util::callback1 send_file_handler);
    void set_send_data_native_handler(std::function<void(const std::string &, char *buf, int length)> send_data_native_handler) {
        send_data_native_handler = send_data_native_handler_;
    }
    void set_fd(int fd);
    void run();
    void handle_get();
    void handle_post();
    void handle_put();

#define MAX_DATA_NUM 0x100
private:
    const std::map<std::string, std::string> &map_header_info_;
    const std::map<std::string, std::string> &map_client_info_;
    std::string &content_;
    lgx::util::callback1 send_file_handler_;
    lgx::util::callback2 send_data_handler_;
    std::function<void(const std::string &, char *buf, int length)> send_data_native_handler_;
    lgx::util::callback2 error_handler_;
    std::map<std::string, std::string> map_url_info_;
    std::map<std::string, std::string> map_url_value_info_;
    std::string request_;
    std::string platform_;

    int fd_;
    void send_data(const std::string &suffix, const std::string &content);
    void send_data(const std::string &suffix, char *buf, int length);
    void send_file(std::string file_name);
    bool parse_url();
    void handle_not_found();
    void response(ResponseCode error_code);
    bool is_dir(const std::string &path);

    // client
    bool client_check_is_none();
    void client_add_data();
    void client_delete_data();
    void client_get_data();
    lgx_data data_list_[MAX_DATA_NUM] = {{nullptr, 0}};
};
