/*@
 * author: i0gan
 */

#pragma once
#include <memory>
#include <unordered_map>
#include <map>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>

#include "base.hh"
#include "util.hh"
#include "work.hh"
enum class lgx::net::HttpRecvState {
    PARSE_HEADER = 0,
    RECV_CONTENT,
    WORK,
    FINISH
};

enum class lgx::net::HttpConnectionState {
    CONNECTED = 0,
    DISCONNECTING,
    DISCONNECTED
};

enum class lgx::net::HttpParseURIResult {
    SUCCESS = 0,
    ERROR
};

enum class lgx::net::HttpParseHeaderResult {
    SUCCESS = 0,
    ERROR
};

enum class lgx::net::HttpResponseCode {
    OK = 200,
    CREATED,
    ACCEPTED,
    NON_AUTHORITATIVE_INFORMATION,
    NO_CONTENT,
    RESET_CONTENT,
    PARTIAL_CONTENT,

    MULTIPLE_CHOICES = 300,
    MOVED_PERMANENTLY,
    FOUND,
    SEE_OTHER,
    NOT_MODIFIED,
    USE_PROXY,
    SWITCH_PROXY,
    TEMPORARY_REDIRCT,
    RESUME_INCOMPLETE,

    BAD_REQUEST = 400,
    UNAUTHORIZED,
    PAYMENT_REAUIRED,
    FORBIDDEN,
    NOT_FOUND,
    METHOD_NOT_ALLOWED,
    NOT_ACCEPTABLE,
    PROXY_AUTHENTICATION_REQUIRED,
    REQUEST_TIMEOUT,
    CONFLICT,
    GONE,
    LENGTH_REQUIRED,
    PRECONDITION_FAILED,
    REQUEST_ENTITY_TOO_LARGE,
    REQUEST_URI_TOO_LONG,
    UNSUPPORTED_MEDIA_TYPE,
    REQUESTED_RANGE_NOT_SATISFIABLE,
    EXPECTATION_FAILED,

    INTERNAL_SERVER_ERROR = 500,
    NOT_IMPLEMENTED,
    BAD_GATEWAY,
    SERVICE_UNAVAILABLE,
    GATEWAY_TIMEOUT,
    HTTP_VERSION_NOT_SUPPORTED,
    NETWORK_AUTHENTICATION_REQUIRED
};

class lgx::net::http_content_type final {
public:
    static std::string get_type(const std::string name);
private:
    static std::unordered_map<std::string, std::string> umap_type_;
    static void init();
    static bool inited;
};

class lgx::net::http final : public std::enable_shared_from_this<http> {
public:
    explicit http(int in_fd, int out_fd);
    ~http();
    void reset();
    void handle_close();
    void handle_read();
    void handle_write();
private:
    int in_fd_ = 0;
    int out_fd_ = 1;
    std::string in_buffer_;
    lgx::util::vessel out_buffer_;
    std::string in_content_buffer_;
    bool recv_error_;
    HttpConnectionState http_connection_state_;
    HttpRecvState http_process_state_;
    int content_length_;
    bool keep_alive_;
    std::map<std::string, std::string> map_header_info_;
    std::map<std::string, std::string> map_client_info_;
    lgx::work::work work_;
    void handle_error(int error_number, std::string message);
    void handle_not_found();
    HttpParseHeaderResult parse_header();

    void handle_work();
    std::string get_suffix(std::string file_name);
    void send_data(const std::string &type,const std::string &content);
    void send_data_native(const std::string &type,char *buf, int length);
    void send_file(const std::string &file_name);
    void str_lower(std::string &str);
};
