/*@
 * author: i0gan
 */

#include "util.hh"
#include <unistd.h>
#include <sys/syscall.h>

ssize_t lgx::net::util::read(int fd, std::string &in_buffer, int size) {
    ssize_t read_len = 0;
    ssize_t read_sum = 0;
    char buffer[MAX_BUF_SIZE];
    in_buffer.clear();
    if((read_len = ::read(fd, buffer, size)) < 0) {
        return read_sum;
    } else if (read_len == 0) {
        in_buffer.clear();
        return 0;
    }
    read_sum += read_len;
    in_buffer += std::string(buffer, buffer + read_len);
    return read_sum;
}

ssize_t lgx::net::util::write(int fd, void *buffer, size_t length) {
    ssize_t write_left = length;
    ssize_t write_len = 0;
    ssize_t write_sum = 0;
    char *write_ptr = static_cast<char *>(buffer);
    while(write_left > 0) {
        if((write_len = ::write(fd, write_ptr, write_left)) < 0) {
            if(errno == EINTR)
                continue;
            else if(errno == EAGAIN) {
                return write_sum;
            }else {
                return -1;
            }
        }
        write_sum += write_len;
        write_left -= write_len;
        write_ptr += write_len;
    }
    return write_sum;
}

ssize_t lgx::net::util::write(int fd, lgx::util::vessel &out_buffer) {
    ssize_t write_len = 0;
    ssize_t write_sum = 0;
    while(out_buffer.size() > 0) {
        write_len = ::write(fd, out_buffer.data(), out_buffer.size());
        if(write_len < 0) {
            if(errno == EINTR)
                continue;
            else if(errno == EAGAIN) {
                return write_sum;
            }else {
                return -1;
            }
        }
        write_sum += write_len;
        out_buffer.sub(write_len);
    }
    return write_sum;
}
