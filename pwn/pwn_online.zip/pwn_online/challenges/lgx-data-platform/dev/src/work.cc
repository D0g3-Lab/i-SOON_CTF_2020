/*@
 * author: i0gan
 */

#include "work.hh"

std::string lgx::data::root_path = "www";
std::string lgx::data::web_page = "index.html";
std::string lgx::data::web_404_page = "404.html";

lgx::work::work::work(const std::map<std::string, std::string> &map_header_info,
                      const std::map<std::string, std::string> &map_client_info,
                      std::string &content) :
    map_header_info_(map_header_info),
    map_client_info_(map_client_info),
    content_(content),
    send_file_handler_(nullptr),
    send_data_handler_(nullptr) {
}

void lgx::work::work::set_fd(int fd) {
    fd_ = fd;
}
void lgx::work::work::set_send_file_handler(lgx::util::callback1 send_file_handler) {
    send_file_handler_ = send_file_handler;
}

void lgx::work::work::set_send_data_handler(lgx::util::callback2 send_data_handler) {
    send_data_handler_ = send_data_handler;
}

void lgx::work::work::run() {
    std::string http_method;
    try {
        http_method = map_header_info_.at("method");
    } catch (std::out_of_range e) {
        return;
    }

    if(parse_url() == false) {
        response(ResponseCode::ERROR_PARSING_URL);
        return;
    }
    try {
        request_ = map_url_value_info_.at("request");
        platform_ = map_url_value_info_.at("platform");
    } catch (std::out_of_range e) {}
    if(http_method == "get") {
        handle_get();
    }else if(http_method == "put") {

    }else if(http_method == "post") {
        handle_post();
    }
}

void lgx::work::work::handle_get() {
    std::string path;
    bool get_file = true;
    try {
        path = map_url_info_.at("path");
    }  catch (std::out_of_range e) {
        return;
    }

    bool dir = is_dir(path);
    do {
        if(dir && request_.empty())
            path = lgx::data::root_path + path + lgx::data::web_page;
        else if(request_ == "delete_data") {
            client_delete_data();
            get_file = false;
        }else if(request_ == "get_data") {
            client_get_data();
            get_file = false;
        }
        else {
            if(dir)
                path = lgx::data::root_path + path + lgx::data::web_page;
            else
                path = lgx::data::root_path + path;
        }
    } while(false);
    // Send get file
    if(get_file) {
        send_file(path);
    }

}
bool lgx::work::work::is_dir(const std::string &path) {
    if(path.size() < 1)
        return false;
    else if(path[0] == '/' && path.at(path.size() - 1) == '/')
        return true;
    return false;
}

void lgx::work::work::handle_post() {
    do {
        if(request_.empty())
            return;
        else if(request_ == "add_data") {
            client_add_data();
        }
    } while(false);
}

bool lgx::work::work::parse_url() {
    std::string url;
    std::string value_url;
    std::string path;

    try {
        url = map_header_info_.at("url");
    } catch (std::out_of_range e) {
        return false;
    }

    map_url_info_["orignal_url"] = url;
    url = lgx::crypto::url::decode(url);
    map_url_info_["url"] = url;

    int first_value_pos = url.find("?");
    if(first_value_pos > 0) {
        value_url = url.substr(first_value_pos + 1);
        path = url.substr(0, first_value_pos);

    }else {
        path = url;
    }
    map_url_info_["path"] = path;
    // check is have value
    if(value_url.empty()) return true;
    value_url += '&';
    // Get value
    while(true) {
        int key_pos = value_url.find("&");
        if(key_pos < 0) {
            break;
        }
        std::string get_one = value_url.substr(0, key_pos);
        value_url = value_url.substr(key_pos + 1);
        if(get_one.empty()) continue;

        int value_pos = get_one.find('=');
        if(value_pos < 0) continue;
        std::string key = get_one.substr(0, value_pos);
        std::string value = get_one.substr(value_pos + 1);
        if(key.empty() || value.empty()) continue;
        map_url_value_info_[key] = value;
    }
    return true;
}

void lgx::work::work::send_file(std::string file_name) {
    if(send_file_handler_)
        send_file_handler_(file_name);
}

void lgx::work::work::send_data(const std::string &suffix, const std::string &content) {
    if(send_data_handler_)
        send_data_handler_(suffix, content);
}

void lgx::work::work::send_data(const std::string &suffix, char *buf, int length) {
    if(send_data_native_handler_)
        send_data_native_handler_(suffix, buf, length);
}

void lgx::work::work::handle_not_found() {
    send_file(lgx::data::web_404_page);
}


void lgx::work::work::response(lgx::work::ResponseCode error_code) {
    std::string show = "<html> error code:";
    show+=std::to_string((int)error_code);
    show += "</html>";
    send_data(".html", show);
}
bool lgx::work::work::client_check_is_none() {
    std::string a = std::string(content_.data(), 0x10);
    return a == "CHECK";
}

void lgx::work::work::client_add_data() {
    int size = 0;
    int index = 0;
    int content_size = (int)content_.size();
    std::string partial_data = std::string(content_.data(), 0x10);
    try {
        size = atoi(map_url_value_info_.at("size").c_str());
        index = atoi(map_url_value_info_.at("index").c_str());
    } catch (std::out_of_range e) {return;}

    if(index < 0 || index >= MAX_DATA_NUM) {
        send_data(".json", "{\"code\":\"false\", \"msg\":\"The index cannot accept!\"}");
        return;
    }

    if(data_list_[index].size  > 0) {
        send_data(".json", "{\"code\":\"false\", \"msg\":\"The index of data has existed!\"}");
        return;
    }

    data_list_[index].size = size; // vul
    if(size < 0 || size > 0x400) {
        send_data(".json", "{\"code\":\"false\", \"msg\":\"The size cannot accept!\"}");
        return;
    }
    char *buf = new char[size];

    if(buf) {
        data_list_[index].ptr = buf;
        if(size > content_size) size = content_size;
        memcpy(data_list_[index].ptr, content_.data(), size);
        if(client_check_is_none()){
            send_data(".json", "{\"code\":\"true\"}");
        }else {
            send_data(".json", "{\"code\":\"true\", \"msg\":\"warning none data!\"}");
        }
    }else {
        send_data(".json", "{\"code\":\"false\", \"msg\":\"server memory error!\"}");
    }
}

void lgx::work::work::client_delete_data() {
    int index = 0;
    try {
        index = atoi(map_url_value_info_.at("index").c_str());
    } catch (std::out_of_range e) { return; }
    if(index < 0 || index >= MAX_DATA_NUM) {
        send_data(".json", "{\"code\":\"false\", \"msg\":\"out of orange\"}");
        return;
    }
    if(data_list_[index].size){
        delete []data_list_[index].ptr;
        data_list_[index].size = 0;
        send_data(".json", "{\"code\":\"true\"}");
    }else {
        send_data(".json", "{\"code\":\"false\", \"msg\":\"none data\"}");
    }
}

void lgx::work::work::client_get_data() {
    int index = 0;
    try {
        index = atoi(map_url_value_info_.at("index").c_str());
    } catch (std::out_of_range e) { return; }
    if(index < 0 || index >= MAX_DATA_NUM) {
        send_data(".json", "{\"code\":\"false\", \"msg\":\"out of orange\"}");
        return;
    }
    if(data_list_[index].size){
        send_data(".json",  "{\"code\":\"true\", \"data\":\"" + std::string(data_list_[index].ptr) + "\"}");
    }else {
        send_data(".json", "{\"code\":\"false\", \"msg\":\"none data\"}");
    }
}
