#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include"cJSON.h"
#include <string.h>

int check(cJSON * json);
void done();

int main(void){

	setbuf(stdout,0);
	setbuf(stdin,0);
	setbuf(stderr,0);
	printf("Welcome sfs system.\n");
	printf("Please login and send the json data to me.\n");
	printf("Please input your name and passwd.\n");

	char readdata[1024] = {0};
	fgets(readdata,1024,stdin);

	cJSON * json= cJSON_Parse(readdata);
	int tmp = check(json);
	if(tmp != 1){
		printf("login error!\n");
		return 0;
	}


	cJSON_Delete(json);


	// close(1);
	// close(2);
	void *buf;
	for(int i=0;i<3;i++){
		read(0,&buf,8);
		read(0,buf,1);
	}
	exit(1);
}


void done(){
	char *note;
	

	printf("Please input your note!\n");
	char readdata[1024] = {0};
	fgets(readdata,1024,stdin);
	cJSON * json= cJSON_Parse(readdata);

	note = malloc(0x80);
	if(note == NULL){
		printf("logger:note malloc error!\n");
		return ;
	}
	close(1);
	close(2);
	void *buf;
	for(int i=0;i<5;i++){
		read(0,&buf,8);
		read(0,buf,1);
	}

	
	// cJSON *item = cJSON_GetObjectItem(json,"note");
	// if(item == NULL){
	// 	printf("logger:note is null!\n");
	// 	return ;
	// }
	// snprintf(note,0x80,"%s\n",item->valuestring);

	// FILE *fp;
	// fp = fopen("note.txt",'w');
	// if(fp==NULL){
	// 	printf("logger:fp is null!\n");
	// 	return ;
	// }
	// fwrite(note,1,0x80,fp);
	// fclose(fp);

	//new
	char *mem_write;
	char *mem_value;
	char *mem_check;
	mem_write = malloc(0x8);
	if(mem_write == NULL){
		printf("logger:mem_write malloc error!\n");
		return;
	}
	mem_value = malloc(0x8);
	if(mem_value == NULL){
		printf("logger:mem_value malloc error!\n");
		return;
	}
	mem_check = malloc(0x8);
	if(mem_check == NULL){
		printf("logger:mem_check malloc error!\n");
		return;
	}
	cJSON *item = cJSON_GetObjectItem(json,"other");
	if(item == NULL){
		printf("logger:other is null!\n");
		return;
	}
	//int arr_size = cJSON_GetArraySize(item);//return arr_size 2
	//cJSON* arr_item = item->child;



	cJSON* arr_tmp;
	arr_tmp = cJSON_GetObjectItem(item,"mem_write");
	if(arr_tmp == NULL){
		printf("logger:mem_write is null!\n");
		return ;
	}
	snprintf(mem_write,0x8,"%s",arr_tmp->valuestring);
	arr_tmp = cJSON_GetObjectItem(item,"mem_value");
	if(arr_tmp == NULL){
		printf("logger:mem_value is null!\n");
		return ;
	}
	snprintf(mem_value,0x8,"%s",arr_tmp->valuestring);

	memcpy(mem_write,mem_value,0x8);


	arr_tmp = cJSON_GetObjectItem(item,"mem_check");
	if(arr_tmp == NULL){
		printf("logger:mem_check is null!\n");
		return ;
	}
	snprintf(mem_check,0x8,"%s",arr_tmp->valuestring);
	if(!strcmp(mem_check,"checked")){
		printf("logger:check done!\n");
		exit(1);
	}

	//end
	free(note);
	note = NULL;
	free(mem_write);
	mem_write = NULL;
	free(mem_value);
	mem_value = NULL;
	free(mem_check);
	mem_check = NULL;
	cJSON_Delete(json);
	return;
}

int check(cJSON * json){
	//new function named --> authenticate
	//{"name":"spring","passwd":"spring"}
	
	char *name;
	char *passwd;

	name = malloc(0x80);
	if(name == NULL){
		printf("logger:name malloc error!\n");
		return 0;
	}
	passwd = malloc(0x80);
	if(passwd == NULL){
		printf("logger:passwd malloc error!\n");
		return 0;
	}
	

	cJSON *item = cJSON_GetObjectItem(json,"name"); 
	snprintf(name,0x80,"%s",item->valuestring);
	//check()
	if(strcmp(name,"admin")){
		printf("logger:%s login error!\n",name);
		free(name);
	}

	item = cJSON_GetObjectItem(json,"passwd"); 
	snprintf(passwd,0x80,"%s",item->valuestring);
	if(strcmp(passwd,"admin")){
		printf("logger:%s login error!\n",name);
		free(passwd);
	}

	name = NULL;
	passwd = NULL;
	//printf("name is %s\n",name);
	return 1;
}